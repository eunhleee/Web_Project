package alcinfo;

public class CSBean {
	private int num;	
	private String cc_title;		
	private String cc_content;	
	private String cc_id;		
	private String cc_pwd;		
	private String cc_regdate;
	private String cc_ip;		
	private String cc_filename;	
	private int cc_filesize;	
	private int cc_count;		
	private int cc_secret;
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getCc_title() {
		return cc_title;
	}
	public void setCc_title(String cc_title) {
		this.cc_title = cc_title;
	}
	public String getCc_content() {
		return cc_content;
	}
	public void setCc_content(String cc_content) {
		this.cc_content = cc_content;
	}
	public String getCc_id() {
		return cc_id;
	}
	public void setCc_id(String cc_id) {
		this.cc_id = cc_id;
	}
	public String getCc_pwd() {
		return cc_pwd;
	}
	public void setCc_pwd(String cc_pwd) {
		this.cc_pwd = cc_pwd;
	}
	public String getCc_regdate() {
		return cc_regdate;
	}
	public void setCc_regdate(String cc_regdate) {
		this.cc_regdate = cc_regdate;
	}
	public String getCc_ip() {
		return cc_ip;
	}
	public void setCc_ip(String cc_ip) {
		this.cc_ip = cc_ip;
	}
	public String getCc_filename() {
		return cc_filename;
	}
	public void setCc_filename(String cc_filename) {
		this.cc_filename = cc_filename;
	}
	public int getCc_filesize() {
		return cc_filesize;
	}
	public void setCc_filesize(int cc_filesize) {
		this.cc_filesize = cc_filesize;
	}
	public int getCc_count() {
		return cc_count;
	}
	public void setCc_count(int cc_count) {
		this.cc_count = cc_count;
	}
	public int getCc_secret() {
		return cc_secret;
	}
	public void setCc_secret(int cc_secret) {
		this.cc_secret = cc_secret;
	}	
	
	
}
