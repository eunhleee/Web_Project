package alcinfo;

public class CSCommentBean {
	private int num;		
	private int ccr_num;		
	private String ccr_id;		
	private String ccr_content;  
	private String ccr_ip;		
	private String ccr_regdate;
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getCcr_num() {
		return ccr_num;
	}
	public void setCcr_num(int ccr_num) {
		this.ccr_num = ccr_num;
	}
	public String getCcr_id() {
		return ccr_id;
	}
	public void setCcr_id(String ccr_id) {
		this.ccr_id = ccr_id;
	}
	public String getCcr_content() {
		return ccr_content;
	}
	public void setCcr_content(String ccr_content) {
		this.ccr_content = ccr_content;
	}
	public String getCcr_ip() {
		return ccr_ip;
	}
	public void setCcr_ip(String ccr_ip) {
		this.ccr_ip = ccr_ip;
	}
	public String getCcr_regdate() {
		return ccr_regdate;
	}
	public void setCcr_regdate(String ccr_regdate) {
		this.ccr_regdate = ccr_regdate;
	}
	
	
}
