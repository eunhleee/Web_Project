package alcinfo;

public class ReportBean {
	private int num;     
	private String  regroup;  
	private String  retitle;   
	private String  recontent;    
	private String  reid;    
	private String  stopid;		
	private String  reip;   
	private String  restate;    
	private String  olddate;	
	private String  newdate;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getRegroup() {
		return regroup;
	}
	public void setRegroup(String regroup) {
		this.regroup = regroup;
	}
	public String getRetitle() {
		return retitle;
	}
	public void setRetitle(String retitle) {
		this.retitle = retitle;
	}
	public String getRecontent() {
		return recontent;
	}
	public void setRecontent(String recontent) {
		this.recontent = recontent;
	}
	public String getReid() {
		return reid;
	}
	public void setReid(String reid) {
		this.reid = reid;
	}
	public String getStopid() {
		return stopid;
	}
	public void setStopid(String stopid) {
		this.stopid = stopid;
	}
	public String getReip() {
		return reip;
	}
	public void setReip(String reip) {
		this.reip = reip;
	}
	public String getRestate() {
		return restate;
	}
	public void setRestate(String restate) {
		this.restate = restate;
	}
	public String getOlddate() {
		return olddate;
	}
	public void setOlddate(String olddate) {
		this.olddate = olddate;
	}
	public String getNewdate() {
		return newdate;
	}
	public void setNewdate(String newdate) {
		this.newdate = newdate;
	} 
	
	
}
