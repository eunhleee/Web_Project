package alcinfo;

public class SCommentBean {
	private int num;	
	private int stuc_pnum;
	private String stuc_nick;
	private String stuc_id;	
	private String stuc_content;
	private String stuc_ip;	
	private String stuc_regdate;
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public int getStuc_pnum() {
		return stuc_pnum;
	}
	public void setStuc_pnum(int stuc_pnum) {
		this.stuc_pnum = stuc_pnum;
	}
	public String getStuc_nick() {
		return stuc_nick;
	}
	public void setStuc_nick(String stuc_nick) {
		this.stuc_nick = stuc_nick;
	}
	public String getStuc_id() {
		return stuc_id;
	}
	public void setStuc_id(String stuc_id) {
		this.stuc_id = stuc_id;
	}
	public String getStuc_content() {
		return stuc_content;
	}
	public void setStuc_content(String stuc_content) {
		this.stuc_content = stuc_content;
	}
	public String getStuc_ip() {
		return stuc_ip;
	}
	public void setStuc_ip(String stuc_ip) {
		this.stuc_ip = stuc_ip;
	}
	public String getStuc_regdate() {
		return stuc_regdate;
	}
	public void setStuc_regdate(String stuc_regdate) {
		this.stuc_regdate = stuc_regdate;
	}
	
	
}
