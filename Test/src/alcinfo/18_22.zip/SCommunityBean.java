package alcinfo;

public class SCommunityBean {
	private int num;
	private String sc_title;
	private String sc_content;
	private String sc_id;
	private String sc_nick;
	private String sc_regdate;
	private String sc_ip;
	private String sc_filename;
	private int sc_filesize;
	private int sc_count;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getSc_title() {
		return sc_title;
	}
	public void setSc_title(String sc_title) {
		this.sc_title = sc_title;
	}
	public String getSc_content() {
		return sc_content;
	}
	public void setSc_content(String sc_content) {
		this.sc_content = sc_content;
	}
	public String getSc_id() {
		return sc_id;
	}
	public void setSc_id(String sc_id) {
		this.sc_id = sc_id;
	}
	public String getSc_nick() {
		return sc_nick;
	}
	public void setSc_nick(String sc_nick) {
		this.sc_nick = sc_nick;
	}
	public String getSc_regdate() {
		return sc_regdate;
	}
	public void setSc_regdate(String sc_regdate) {
		this.sc_regdate = sc_regdate;
	}
	public String getSc_ip() {
		return sc_ip;
	}
	public void setSc_ip(String sc_ip) {
		this.sc_ip = sc_ip;
	}
	public String getSc_filename() {
		return sc_filename;
	}
	public void setSc_filename(String sc_filename) {
		this.sc_filename = sc_filename;
	}
	public int getSc_filesize() {
		return sc_filesize;
	}
	public void setSc_filesize(int sc_filesize) {
		this.sc_filesize = sc_filesize;
	}
	public int getSc_count() {
		return sc_count;
	}
	public void setSc_count(int sc_count) {
		this.sc_count = sc_count;
	}
	
	
}
